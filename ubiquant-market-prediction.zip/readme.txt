Hi All,

At the request of the competition host, we have removed the dataset from this competition - therefore Late Submissions will not be available.

Regards,

Kaggle Team